---
home: true
icon: home
title: Nonebot-plugin-novelai
heroImage:
heroText: MutsukiBot
tagline: 基于Nonebot的novelai使用说明书
actions:
  - text: 使用手册
    link: /main
    type: primary
  - text: 更新日志
    link: /update

features:
  - title: 世界第一可爱的梦月酱
    icon: creative
    details: 欸嘿~
    link: /

copyright: MIT Licensed / CC-BY-NC-SA | Copyright © 2022-present 星奈 Sena
footer: 后面没有了哦~
---
